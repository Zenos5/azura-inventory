const express = require('express');
const bodyParser = require("body-parser");

const app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
  extended: false
}));

const mongoose = require('mongoose');

// connect to the database
mongoose.connect('mongodb://localhost:27017/inventory', {
  useNewUrlParser: true
});

// Configure multer so that it will upload to '../front-end/public/images'
const multer = require('multer')
const upload = multer({
  dest: '/var/www/inventory.angel4right.com/images/',
  limits: {
    fileSize: 10000000
  }
});

// Create a scheme for items in the inventory: a title and a path to an image.
const equipSchema = new mongoose.Schema({
  title: String,
  description: String,
  path: String,
});
const statSchema = new mongoose.Schema({
  title: String,
  description: String,
});

// Create a model for items in the inventory.
const Equipment = mongoose.model('Equipment', equipSchema);
const Spell = mongoose.model('Spell', statSchema);
const Stat = mongoose.model('Stat', statSchema);

// Upload a photo. Uses the multer middleware for the upload and then returns
// the path where the photo is stored in the file system.
app.post('/api/photos', upload.single('photo'), async (req, res) => {
  // Just a safety check
  if (!req.file) {
    return res.sendStatus(400);
  }
  res.send({
    path: "/images/" + req.file.filename
  });
});

// Create a new item in the inventory: takes a title and a path to an image.
app.post('/api/objects', async (req, res) => {
  const object = new Equipment({
    title: req.body.title,
    description: req.body.description,
    path: req.body.path,
  });
  try {
    await object.save();
    res.send(object);
  } catch (error) {
    console.log(error);
    res.sendStatus(500);
  }
});
app.post('/api/stats', async (req, res) => {
  const stat = new Stat({
    title: req.body.title,
    description: req.body.description
  });
  try {
    await stat.save();
    res.send(stat);
  } catch (error) {
    console.log(error);
    res.sendStatus(500);
  }
});
app.post('/api/spells', async (req, res) => {
  const spell = new Spell({
    title: req.body.title,
    description: req.body.description
  });
  try {
    await spell.save();
    res.send(spell);
  } catch (error) {
    console.log(error);
    res.sendStatus(500);
  }
});

// Get a list of all of the items in the inventory.
app.get('/api/objects', async (req, res) => {
  try {
    let objects = await Equipment.find();
    res.send(objects);
  } catch (error) {
    console.log(error);
    res.sendStatus(500);
  }
});
app.get('/api/spells', async (req, res) => {
  try {
    let spells = await Spell.find();
    res.send(spells);
  } catch (error) {
    console.log(error);
    res.sendStatus(500);
  }
});
app.get('/api/stats', async (req, res) => {
  try {
    let stats = await Stat.find();
    res.send(stats);
  } catch (error) {
    console.log(error);
    res.sendStatus(500);
  }
});

//delete item
app.delete('/api/objects/:id', async (req, res) => {
  try {
    await Equipment.deleteOne({
      _id: req.params.id
    });
    res.sendStatus(200);
  } catch (error) {
    console.log(error);
    res.sendStatus(500);
  }
});
app.delete('/api/spells/:id', async (req, res) => {
  try {
    await Spell.deleteOne({
      _id: req.params.id
    });
    res.sendStatus(200);
  } catch (error) {
    console.log(error);
    res.sendStatus(500);
  }
});
app.delete('/api/stats/:id', async (req, res) => {
  try {
    await Stat.deleteOne({
      _id: req.params.id
    });
    res.sendStatus(200);
  } catch (error) {
    console.log(error);
    res.sendStatus(500);
  }
});

//edit item
app.put('/api/objects/:id', async (req, res) => {
  try {
    let object = await Equipment.findOne({
      _id: req.params.id
    });
    object.title = req.body.title;
    object.description = req.body.description;
    object.save();
    res.sendStatus(200);
  } catch (error) {
    console.log(error);
    res.sendStatus(500);
  }
});
app.put('/api/spells/:id', async (req, res) => {
  try {
    let spell = await Spell.findOne({
      _id: req.params.id
    });
    spell.title = req.body.title;
    spell.description = req.body.description;
    spell.save();
    res.sendStatus(200);
  } catch (error) {
    console.log(error);
    res.sendStatus(500);
  }
});
app.put('/api/stats/:id', async (req, res) => {
  try {
    let stat = await Stat.findOne({
      _id: req.params.id
    });
    stat.title = req.body.title;
    stat.description = req.body.description;
    stat.save();
    res.sendStatus(200);
  } catch (error) {
    console.log(error);
    res.sendStatus(500);
  }
});


app.listen(3003, () => console.log('Server listening on port 3003!'));
