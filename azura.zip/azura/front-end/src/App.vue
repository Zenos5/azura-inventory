<template>
<div id="app">
  <div class="header">
    <router-link to="/">
      <div class="logo">
        <img src="/dice.png" width="75">
      </div>
    </router-link>
    <div class="title">
      <h1> Azura's Inventory</h1>
    </div>
  </div>
  <div class="content">
    <router-view />
  </div>
  <div class="footer">
    <router-link to="/equipment">Equipment</router-link>
    <p> </p>
    <router-link to="/spells">Spells</router-link>
    <p> </p>
    <router-link to="/stats">Stats</router-link>
    <p> </p>
  </div>
  <div class="git">
    <a href="https://github.com/Zenos5/azura-inventory">https://github.com/Zenos5/azura-inventory</a> 
  </div>
</div>
</template>

<style>
html {
  box-sizing: border-box;
}

body {
  font-family: 'Montserrat', sans-serif;
  font-size: 16px;
  background: #fff;
  padding: 0px;
  margin: 0px;
}

/* Header */
.header {
  display: flex;
  padding: 10px 100px 0px 100px;
  background-color: #F70D1A;
  color: #1C454F;
}

.title {
  margin-top: 5px;
}

.title h1 {
  font-size: 30px;
}

.content {
  padding: 20px 100px;
  min-height: 500px;
}

/* Footer */
.footer {
  height: 50px;
  padding: 20px 100px 0px 100px;
  background: #e3e3e3;
  font-size: 12px;
}

.footer a {
  color: #000;
}

.git {
  background: #e3e3e3;
  height: 50px;
  padding: 20px 100px 0px 100px; 
}

h1 {
  font-size: 20px;
}

h2 {
  font-size: 14px;
}
</style>
