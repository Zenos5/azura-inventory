<template>
<div class="admin">
  <h1>The Statistics Page!</h1>
    <div class="heading">
      <div class="circle">1</div>
      <h2>Add a Stat</h2>
    </div>
    <div class="add">
      <div class="form">
        <input v-model="title" placeholder="Title">
        <p></p>
	<input type="textarea" v-model="description" placeholder="Description">
        <p></p>        
        <button @click="upload">Upload</button>
      </div>
      <div class="upload" v-if="addStat">
        <h2>{{addStat.title}}</h2>
	<h4>{{addStat.description}}</h4>
      </div>
    </div>
    <div class="heading">
      <div class="circle">2</div>
      <h2>Edit/Delete a Stat</h2>
    </div>
    <div class="edit">
      <div class="form">
        <input v-model="findStat" placeholder="Search">
        <div class="suggestions" v-if="suggestions.length > 0">
          <div class="suggestion" v-for="s in suggestions" :key="s.id" @click="selectStat(s)">{{s.title}}
          </div>
        </div>
      </div>
      <div class="upload" v-if="findStat">
        <input v-model="findStat.title">
	<p></p>
	<input v-model="findStat.description">
        <p></p>
      </div>
      <div class="actions" v-if="findStat">
        <button @click="deleteStat(findStat)">Delete</button>
	<button @click="editStat(findStat)">Edit</button>
      </div>
    </div>
</div>
</template>

<script>
import axios from 'axios';
export default {
  name: 'Stats',
  data() {
    return {
      title: "",
      file: null,
      description: "",
      addStat: null,
      stats: [],
      findTitle: "",
      findStat: null,
    }
  },
  computed: {
    suggestions() {
      let stats = this.stats.filter(stat => stat.title.toLowerCase().startsWith(this.findTitle.toLowerCase()));
      return stats.sort((a, b) => a.title > b.title);
    }
  },
  created() {
    this.getStats();
  },
  methods: {
    fileChanged(event) {
      this.file = event.target.files[0]
    },
    async upload() {
      try {
        const formData = new FormData();
        formData.append('photo', this.file, this.file.name)
        let r2 = await axios.post('/api/stats', {
          title: this.title,
          description: this.description,
        });
        this.addStat = r2.data;
      } catch (error) {
        console.log(error);
      }
    },
    async getStats() {
      try {
        let response = await axios.get("/api/stats");
        this.stats = response.data;
        return true;
      } catch (error) {
        console.log(error);
      }
    },
    selectStat(stat) {
      this.findTitle = "";
      this.findStat = stat;
    },
    async deleteStat(stat) {
      try {
        await axios.delete("/api/stats/" + stat._id);
        this.findStat = null;
        this.getStats();
        return true;
      } catch (error) {
        console.log(error);
      }
    },
    async editStat(stat) {
      try {
        await axios.put("/api/stats/" + stat._id, {
          title: this.findStat.title,
          description: this.findStat.description,
        });
        this.findStat = null;
        this.getStats();
        return true;
      } catch (error) {
        console.log(error);
      }
    },
  }
}
</script>

<style scoped>
.image h2 {
  font-style: italic;
  font-size: 1em;
}

.heading {
  display: flex;
  margin-bottom: 20px;
  margin-top: 20px;
}

.heading h2 {
  margin-top: 8px;
  margin-left: 10px;
}

.add,
.edit {
  display: flex;
}

.circle {
  border-radius: 50%;
  width: 18px;
  height: 18px;
  padding: 8px;
  background: #333;
  color: #fff;
  text-align: center
}

/* Form */
input,
textarea,
select,
button {
  font-family: 'Montserrat', sans-serif;
  font-size: 1em;
}

.form {
  margin-right: 50px;
}

/* Uploaded images */
.upload h2 {
  margin: 0px;
}

.upload img {
  max-width: 300px;
}

/* Suggestions */
.suggestions {
  width: 200px;
  border: 1px solid #ccc;
}

.suggestion {
  min-height: 20px;
}

.suggestion:hover {
  background-color: #5BDEFF;
  color: #fff;
}
</style>
